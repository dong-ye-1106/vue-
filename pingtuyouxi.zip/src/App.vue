<template>
<div id="app">
    <router-view></router-view>
</div>
</template>

<script>
export default {
    name: "App",
    components: {},
    created() {
      const { dispatch } = this.$store;
      console.log('来源地址是'+document.referrer);
    // dispatch("SET_FILEIP");
    },
};
</script>

<style>
</style>
