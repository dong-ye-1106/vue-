import Vue from "vue"
import Router from "vue-router"
Vue.use(Router)
const index = resolve => require(['@/views/index/Index.vue'], resolve)
const report = resolve => require(['@/views/report/Index.vue'], resolve)
export default new Router({
    mode: 'history',
    routes: [
        {
            path: "/",
            name: "index",
            redirect: "/info",
            component: index,
            children: [
                {
                    path: "info",
                    name: "info",
                    component: index
                },
            ]
        },
        {
            path: "/report",
            name: "report",
            component: report
        },
    ]
})