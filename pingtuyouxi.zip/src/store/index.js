import Vue from 'vue'
import Vuex from 'vuex'
import api from "@/api"
Vue.use(Vuex)
export var store = new Vuex.Store({
    state: {
        fileIp: "",
        Company:"",
    },
    mutations: {
        SET_FILEIP(state, fileIp) {
            state.fileIp = fileIp
            // console.log(state.fileIp,222)
        },
        set_Company(state,Company){
            state.Company=Company
            // console.log(state.Company,"state.Company")
        }
    },
    actions: {
        SET_FILEIP({ commit }) {
            return new Promise((resolve) => {
                api.getIp().then(res => {
                    commit('SET_FILEIP', res.data)
                    resolve();
                });
            })
        },
        
    }
})