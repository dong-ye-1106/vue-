import common from "./common"
const Api = Object.assign({},common)
export default Api