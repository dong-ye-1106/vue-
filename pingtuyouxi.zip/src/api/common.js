import {
    $get,
    $post
} from '@/utils/http'

export default {
    //法律法规列表
    regulationPage(params) {
        return $post('/h5/supervise/complain/regulation-page', params)
    },
}
