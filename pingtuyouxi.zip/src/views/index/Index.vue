<template>
<div class="container">
    <div class="top-box">
        拼图组件开发
        <pingtu></pingtu>
    </div>
</div>
</template>

<script>
import pingtu from '@/components/pingtu.vue';
export default {
    data() {
        return {
            
        };
    },
    components:{
        pingtu
    },
    created() {
        document.title = "测试模板";
        console.log('来源地址是'+document.referrer);
    },
    methods: {

    },
};
</script>

<style lang="less" scoped>

</style>
