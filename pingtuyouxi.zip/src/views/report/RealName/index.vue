<template>
<div class="box">
    <div class="height-160"></div>
    <van-nav-bar :fixed="true" title="实名认证" left-text left-arrow @click-left="onClickLeft" />
    <van-form @submit="onSubmit">
        <!--举报人信息-->
        <div class="report-people-box">
            <div class="people-form">
                <van-field v-model="ruleForm.name1" label="姓名" placeholder="请输入姓名" required :rules="[{ required: true, message: '请输入姓名' }]" maxlength="255" />
                <van-field v-model="ruleForm.name2" label="身份证号" placeholder="请输入身份证号" required :rules="[{ pattern, message: '请输入正确的身份证号' }]" maxlength="255" />
                <van-field v-model="ruleForm.name3" label="联系方式" placeholder="请输入联系方式" required :rules="[{ required: true, message: '请输入联系方式' }]" maxlength="255" />
                <!--政治面貌-->
                <div class="Company-box">
                    <van-field readonly clickable label="政治面貌" :value="ruleForm.Companyzhengzi" placeholder="请选择" @click="zengzhi = true" is-link maxlength="255" />
                </div>
                <!--现居地址-->
                <van-field v-model="ruleForm.message2" rows="1" autosize label="现居地址" type="textarea" placeholder="请输入现居地址" class="text-title" maxlength="255" />
                <!--工作单位-->
                <van-field v-model="ruleForm.name4" label="工作单位" placeholder="请输入工作单位" maxlength="255" />
            </div>
        </div>
        <!--提 交-->
        <div class="but-submit-box">

            <div v-if="ruleForm.name1 && ruleForm.name2 && ruleForm.name3" :style="{width:'100%'}">
                <van-uploader :before-read="beforeRead" accept="image/*" capture="camera">
                    <van-button round block type="info" native-type="submit" capture>下一步</van-button>
                </van-uploader>
            </div>
            <van-button round block type="info" native-type="submit" v-else>下一步</van-button>
            <span class="bt-tip">点击下一步进行人脸识别</span>
        </div>
    </van-form>
    <!--调取摄像头-->
    <!--
    <input
      class="file"
      ref="videoFace"
      name="file"
      type="file"
      accept="image/*"
      capture="user"
      @change="updateFace"
    />-->
    <!--调取摄像头结束-->
    <!--政治面貌-->
    <van-popup v-model="zengzhi" round position="bottom">
        <van-picker show-toolbar :columns="columns2" @cancel="zengzhi = false" @confirm="onConfirm3" />
    </van-popup>
</div>
</template>

<script>
import Vue from "vue";
import {
    Form,
    Field,
    Popup,
    Picker,
    Icon,
    Uploader,
    Button,
    NavBar,
    Toast,
    Notify
} from "vant";
// Vue.use(Form, Field,Popup,Picker );
Vue.use(Form);
Vue.use(Field);
Vue.use(Popup);
Vue.use(Picker);
Vue.use(Icon);
Vue.use(Uploader);
Vue.use(Button);
Vue.use(NavBar);
Vue.use(Toast);
Vue.use(Notify);
export default {
    data() {
        return {
            pattern: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/,
            zengzhi: false,
            ruleForm: {
                name1: "",
                name2: "",
                name3: "",
                name4: "",
                Companyzhengzi: "",
                message2: "",
            },
            columns2: [],
        };
    },
    created() {
        document.title = "实名举报";
        this.getDropDownlsit()
    },
    methods: {
        // 返回布尔值,图片上上传前触发，保存数据，掉接口
        beforeRead(file) {
            this.Api.getRealNameReport({
                name: this.ruleForm.name1,
                idCard: this.ruleForm.name2,
            }).then(res => {
                if (res) {
                    let arr = JSON.stringify(this.ruleForm)
                    sessionStorage.setItem("USER_DETAIL", arr)
                    // console.log(res, "res")
                    // Toast({
                    //     message: '实名认证成功',
                    //     position: 'top',
                    // });
                    Notify({
                        type: 'success',
                        message: '实名认证成功'
                    });
                    this.$router.push({
                        name: "ReportPeople",
                    });
                    return true;
                } else {
                    return false;
                }
            })

        },
        //阵子面貌列表获取
        getDropDownlsit() {
            const _this = this
            this.Api.getDropDownlsit({
                typeCode: "POLITICAL_OUTLOOK"
            }).then(res => {
                if (res) {
                    // console.log(res, "xialai列表")
                    res.data.forEach(function (item, index) {
                        _this.columns2.push(item.itemName)
                    })

                }
                // console.log(this.columns2, "this.columns2")
            })
        },
        onClickLeft() {
            // Toast("返回");
            this.$router.push({
                name: "info"
            });
            // history.back();
        },
        //表单提交时间。只有当校验通过时才会触发
        onSubmit(values) {
            console.log("submit", values);
        },
        onConfirm3(value) {
            this.ruleForm.Companyzhengzi = value;
            this.zengzhi = false;
        },
        afterRead(file) {
            //  console.log("!111111111")
            this.$router.push({
                name: "ReportPeople",
            });
        },
        // updateFace(e) {
        //   const file = e.target.files[0] || e.dataTransfer.files[0];
        //   if (file) {
        //     // 本地预览
        //     const reader = new FileReader();
        //     const myVideo = document.querySelector("#video");
        //     reader.onloadend = (evt) => {
        //       myVideo.src = evt.target.result;
        //     };
        //     reader.readAsDataURL(file);
        //     myVideo.play();

        //     // 上传
        //     const fd = new FormData();
        //     fd.append("file", file);
        //     ocrIdCard(fd)
        //       .then((response) => {
        //         if (response) {
        //           console.log(response);
        //         }
        //       })
        //       .catch(() => {});
        //   }
        // },
    },
};
</script>

<style lang="less" scoped>
//导航栏的样式
/deep/.van-nav-bar--fixed {
    .van-nav-bar__left {
        padding-left: 0.4rem;

        i {
            color: #333333;
            width: 0.27rem;
            height: 0.49rem;
        }
    }

    .van-nav-bar__title {
        font-size: 0.48rem;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 600;
        color: rgba(0, 0, 0, 1);
        line-height: 0.67rem;
    }
}

.height-160 {
    height: 1.23rem;
}

/deep/.van-picker-column__item--selected {
    .van-ellipsis {
        color: #dd2126;
    }
}

/deep/.van-picker__confirm {
    color: #dd2126;
}

//输入框的lable
/deep/.van-field__label {
    font-size: 0.37rem;
    font-weight: 600;
    color: rgba(51, 51, 51, 1);
    line-height: 0.59rem;
    //   text-align: right;
}

//提交按钮的样式
.but-submit-box {
    padding: 0.48rem 0.4rem 0.68rem 0.4rem;
    background-color: #f0f2f5;
    display: flex;
    flex-direction: column;
    align-items: center;

    .van-button--info {
        background: rgba(221, 33, 38, 1);
        border: 0.01rem solid #dd2126;

        .van-button__text {
            font-size: 0.43rem;
            font-weight: 400;
            color: rgba(255, 255, 255, 1);
            line-height: 0.64rem;
            letter-spacing: 0.2rem;
        }
    }

    .bt-tip {
        font-size: 0.35rem;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #B2B2B2;
        line-height: 0.79rem;

    }
}

/deep/.van-uploader {
    width: 100%;

    .van-uploader__input-wrapper {
        width: 100%;
    }
}
</style>
