<template>
<div>
    <div class="height-160"></div>
    <van-nav-bar :fixed="true" title="被举报人详情" left-text left-arrow @click-left="onClickLeft" />
    <div class="form-box">
        <van-form @submit="onSubmit">
            <div class="Company-box">
                <!--单位-->
                <van-field readonly clickable label="单位" :value="ruleForm.Company" placeholder="选择单位" @click="showPicker = true" required :rules="[{ required: true, message: '' }]" />
                <van-icon name="arrow" />
            </div>

            <!--被举报人姓名-->
            <van-field required v-model="ruleForm.reportname" label="被举报人姓名" placeholder="请输入被举报人姓名" :rules="[{ required: true, message: '' }]" @focus="nameFocus" maxlength="255" />
            <!--职务-->
            <van-field required v-model="ruleForm.reportname1" label="职务" placeholder="请输入被举报人职务" :rules="[{ required: true, message: '' }]" maxlength="255" />
            <!--级别-->
            <van-field required v-model="ruleForm.reportname2" label="级别" placeholder="请输入级别" :rules="[{ required: true, message: '' }]" maxlength="255" />
            <!--标题-->
            <van-field v-model="ruleForm.message" rows="1" autosize label="标题" type="textarea" placeholder="请输入标题 < 50字符" class="text-title" required :rules="[{ required: true, message: '' }]" maxlength="50" />
            <!--问题类别-->
            <div class="Company-box">
                <van-field readonly clickable label="问题类别" :value="ruleForm.Company1" placeholder="请选择" @click="showPicker1 = true" required :rules="[{ required: true, message: '' }]" />
                <van-icon name="arrow" />
            </div>
            <!--问题细类-->
            <div class="Company-box">
                <van-field readonly clickable label="问题细类" :value="ruleForm.Company2" placeholder="请选择" @click="showPicker2 = true" required :rules="[{ required: true, message: '' }]" />
                <van-icon name="arrow" />
            </div>
            <!--举报问题-->
            <van-field v-model="ruleForm.message1" rows="1" autosize label="举报问题" type="textarea" placeholder="请输入举报问题（ < =3000字符）" class="text-title" required :rules="[{ required: true, message: '' }]" maxlength="3000" />
            <!--图片上传-->
            <div class="uploader-box">
                <!--accept=".avi,audio/mp4, video/mp4,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/pdf,.png,.jpg,.jpeg,application/vnd.ms-excel"-->
                <div class="pic-upload" @click="showUpload = true">
                    <div class="van-field__label">附件上传</div>
                    <van-icon name="photo" color="#3D7FFF" size="0.53rem" />
                </div>
                <div class="file-box">
                    <div class="item" v-for="(item,index) in fileList " :key="index">
                        <img v-if="item.type==='pdf'" src="@/assets/image/pdfpic.png" alt />
                        <img v-if="item.type==='doc'" src="@/assets/image/wordpic.png" alt />
                        <img v-if="item.type==='docx'" src="@/assets/image/wordpic.png" alt />
                        <img v-if="item.type==='mp4'" src="@/assets/image/mp4pic.png" alt />
                        <img v-if="item.type==='avi'" src="@/assets/image/avipic.png" alt />
                        <img v-if="item.type==='xls'" src="@/assets/image/excelpic.png" alt />
                        <img v-if="item.type==='xlsx'" src="@/assets/image/excelpic.png" alt />

                        <img v-if="item.type==='jpg'" :src="baseUrl+item.url" alt />
                        <img v-if="item.type==='png'" :src="baseUrl+item.url" alt />
                        <img v-if="item.type==='jpeg'" :src="baseUrl+item.url" alt />
                        <span @click="removePdf(index)">x</span>
                    </div>
                </div>
                <!--
                <div class="upload-tip">温馨提示：最多上传5个附件，每个附件不超过30M，附件后缀名为pdf，mp4，avi，jpg，png，jpeg，xls，xlsx，doc，docx。</div>
                -->
                <van-progress :percentage="percentageNmb" v-if="percentageIsTrue" />
            </div>
            <!--举报人信息-->
            <div class="report-people-box">
                <div class="people-title">举报人信息</div>
                <div class="people-form">
                    <van-field v-model="ruleForm.name1" label="姓名" placeholder="请输入姓名" maxlength="255" />
                    <van-field v-model="ruleForm.name2" label="身份证号" placeholder="请输入身份证号" maxlength="255" />
                    <van-field v-model="ruleForm.name3" label="联系方式" placeholder="请输入联系方式" maxlength="255" />
                    <!--政治面貌-->
                    <div class="Company-box">
                        <van-field readonly clickable label="政治面貌" :value="ruleForm.Companyzhengzi" placeholder="请选择" @click="zengzhi = true" maxlength="255" />
                        <van-icon name="arrow" />
                    </div>
                    <!--现居地址-->
                    <van-field v-model="ruleForm.message2" rows="1" autosize label="现居地址" type="textarea" placeholder="请输入现居地址" class="text-title" maxlength="255" />
                    <!--工作单位-->
                    <van-field v-model="ruleForm.name4" label="工作单位" placeholder="请输入工作单位" maxlength="255" />
                </div>
            </div>
            <!--提 交-->
            <div class="but-submit-box">
                <van-button round block type="info" native-type="submit">提交</van-button>
            </div>
        </van-form>
        <!--表单结束-->
    </div>
    <!--弹出窗区域========================================================-->
    <!--单位-->
    <van-popup v-model="showPicker" round position="bottom">
        <van-picker show-toolbar :columns="columns" @cancel="showPicker = false" @confirm="onConfirm" />
    </van-popup>
    <!--问题类别-->
    <van-popup v-model="showPicker1" round position="bottom">
        <van-picker show-toolbar :columns="columns1" @cancel="showPicker1 = false" @confirm="onConfirm1" />
    </van-popup>
    <!--问题细类-->
    <van-popup v-model="showPicker2" round position="bottom">
        <van-picker show-toolbar :columns="columns2" @cancel="showPicker2 = false" @confirm="onConfirm2" />
    </van-popup>
    <!--政治面貌-->
    <van-popup v-model="zengzhi" round position="bottom">
        <van-picker show-toolbar :columns="columns3" @cancel="zengzhi = false" @confirm="onConfirm3" />
    </van-popup>
    <!--搜索遮罩层的弹出-->
    <van-overlay :show="show" @click="show = false">
        <div class="wrapper" @click.stop>
            <div class="block">
                <div class="box">
                    <form action="/">
                        <van-search v-model="value" show-action shape="round" placeholder="请输入搜索关键词" @cancel="onCancel" @search="onSearch" :autofocus="true" />
                    </form>
                    <!--人员列表展示区域-->
                    <ul>
                        <li v-for="(item,index) in searchMethod" :key="index" @click="choiceValueName(item)">
                            <div class="name">{{item.personName}}</div>
                            <div class="lable">{{item.personPost}}</div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </van-overlay>
    <!--上传区域的改动-->
    <van-action-sheet v-model="showUpload" title="上传附件" class="pic-upload-choice-box" cancel-text="取消">
        <div @click="showUpload=false">
            <van-uploader accept=image/* v-model="fileList" :max-count="5" :after-read="afterRead" :preview-image="false" :max-size="1024 * 1024 * 30" @oversize="onOversize" :before-read="beforeRead">
                <div class="pic-upload-choice">图片上传</div>
            </van-uploader>
        </div>
        <div @click="showUpload=false">
            <van-uploader accept="video/*" v-model="fileList" :max-count="5" :after-read="afterRead" :preview-image="false" :max-size="1024 * 1024 * 30" @oversize="onOversize" :before-read="beforeRead">
                <div class="pic-upload-choice">视频上传</div>
            </van-uploader>
        </div>

    </van-action-sheet>
</div>
</template>

<script>
import Vue from "vue";
import {
    Form,
    Field,
    Popup,
    Picker,
    Icon,
    Uploader,
    Button,
    NavBar,
    Toast,
    Overlay,
    Search,
    Notify,
    ActionSheet,
    Progress
} from "vant";
import picPdf from '@/assets/image/pdf.png'
// Vue.use(Form, Field,Popup,Picker );
Vue.use(Form);
Vue.use(Field);
Vue.use(Popup);
Vue.use(Picker);
Vue.use(Icon);
Vue.use(Uploader);
Vue.use(Button);
Vue.use(NavBar);
Vue.use(Toast);
Vue.use(Overlay);
Vue.use(Search);
Vue.use(Notify);
Vue.use(ActionSheet);
Vue.use(Progress);
export default {
    data() {
        return {
            timer: null,
            percentageIsTrue: false,
            percentageNmb: 1,
            showUpload: false,
            attachList2: [],
            list: [],
            value: "",
            show: false,
            ruleForm: {
                Company: "",
                reportname: "",
                reportname1: "",
                reportname2: "",
                message: "",
                Company1: "",
                Company2: "",
                message1: "",
                name1: "",
                name2: "",
                name3: "",
                name4: "",
                Companyzhengzi: "",
                message2: "",
            },

            zengzhi: false,

            fileList: [],

            showPicker: false,
            showPicker1: false,
            showPicker2: false,
            columns: [],
            columnsCopy: [],
            columns1: [],
            columns2: [],
            columns3: [],
            questionList: [],
            attachList: [],
            questionList2: [],
            //问题类别的后台需要值保存
            savevalue1: "",
            //问题细类的后台需要值保存
            savevalue2: "",
            attachList: [],
            //被举报人单位id
            danweiID: "",
            picPdf: picPdf
        };
    },
    computed: {
        searchMethod() {
            if (this.value) {
                return this.list.filter((value) => {
                    return value.personName.indexOf(this.value) > -1;
                });
            } else {
                return [];
            }
        },
        baseUrl() {
            return this.$store.state.fileIp
        }
    },
    created() {
        document.title = "匿名举报";
        this.getCompany();
        this.getDropDownlsit()
    },
    methods: {
        // 图片上传的修改============================================================================
        //限制图片上传的大小
        onOversize(file) {
            // console.log(file);
            Toast('文件大小不能超过 30M');
        },
        //上传的前置处理，限制上传图片的类型
        beforeRead(file) {
            // console.log(file, "file")
            if (["application/pdf", "video/mp4", "video/avi", "image/jpg", "image/png", "image/jpeg", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"].indexOf(file.type) === -1) {
                // console.log("上传失败")
                Toast('请上传指定格式附件');
                return false;
            }
            return true;
        },
        removePdf(index) {
            this.attachList.splice(index, 1)
            this.fileList.splice(index, 1)
            this.percentageIsTrue = false;
            // console.log(this.attachList, "this.attachList111111")
        },
        //d单位列表的获取
        getCompany() {
            const _this = this;
            //单位接口
            this.Api.getCompany().then((res) => {
                if (res) {
                    this.columnsCopy = res.data;
                    _this.columns = [];
                    res.data.forEach(function (item, index) {
                        _this.columns.push(item.name);
                    });
                }
            });
            //问题类别
            this.Api.getDropDownlsit({
                typeCode: "ISSUE_TYPE",
            }).then((res) => {
                if (res) {
                    _this.columns1 = [];
                    this.questionList = res.data;
                    // console.log(res, "xialai列表")
                    res.data.forEach(function (item, index) {
                        _this.columns1.push(item.itemName);
                    });
                }
            });
        },
        //人名获取焦点时将单位的id带过去
        nameFocus() {
            this.show = true;
            const _this = this;
            let item = this.columnsCopy.filter(function (item, index, arry) {
                return item.name === _this.ruleForm.Company;
            });
            // console.log(item)
            if (item.length > 0) {
                this.danweiID = item[0].id;
                this.Api.getPeopleName({
                    id: item[0].id,
                }).then((res) => {
                    if (res) {
                        // console.log(res, "res");
                        this.list = res.data;
                    }
                });
            } else {
                this.list = [];
            }
        },
        //遮罩层弹出取消时触发
        onCancel() {
            this.show = false;
        },
        // 收缩框
        onSearch(val) {
            this.show = false;
            this.ruleForm.reportname = this.value;
        },
        //人名的列表触发
        choiceValueName(item) {
            this.show = false;
            this.ruleForm.reportname = item.personName;
            this.ruleForm.reportname1 = item.personPost;
        },
        //问题细类的获取方式,在问题类别的选择后调用该函数
        inputChange() {
            //问题细类
            const _this = this;
            let item11 = this.questionList.filter(function (item, index, arry) {
                return item.itemName === _this.ruleForm.Company1;
            });
            this.savevalue1 = item11[0].itemValue;
            // console.log(item, " item")
            this.Api.getDropDownlsit({
                typeCode: "ISSUE_CHILD_TYPE",
                pItemValue: item11[0].itemValue,
            }).then((res) => {
                if (res) {
                    // console.log(res.data, "问题细类列表");
                    _this.columns2 = [];
                    this.questionList2 = res.data;
                    res.data.forEach(function (item, index) {
                        _this.columns2.push(item.itemName);
                    });
                }
            });
        },
        //图片上传的方法
        afterRead(file) {
            // console.log(file, "file");
            // console.log(this.fileList, "filelist");
            // console.log(typeof (this.percentageNmb))
            const _this = this
            this.percentageIsTrue = true
            _this.percentageNmb = 2;
            console.log(typeof (_this.percentageNmb))
            _this.timer = setInterval(function () {
                ++_this.percentageNmb
                if (_this.percentageNmb === 80) {
                    _this.attachList.splice(_this.attachList.length - 1, 1)
                    _this.fileList.splice(_this.fileList.length - 1, 1)
                    Toast.fail('网速过慢，上传超时');
                    _this.percentageIsTrue = false;
                    clearInterval(_this.timer);
                }
                console.log(_this.percentageNmb, "111111")
            }, 2000)
            //上传的文件类型
            var FileExt = file.file.name.replace(/.+\./, "");
            if (["jpg", "png", "jpeg"].indexOf(
                    FileExt.toLowerCase()
                ) !== -1) {
                let formData = new FormData();
                formData.append("file", file.file);
                this.Api.uploadImage(formData).then(res => {
                    console.log(res, "上传的图片文件")
                    this.$set(this.fileList, this.fileList.length - 1, {
                        name: file.file.name,
                        type: FileExt,
                        url: res.data.url,
                        size: file.file.size
                    })
                    // console.log(this.fileList, "newfilelist");
                    _this.percentageNmb = 100;
                    setTimeout(function () {
                        _this.percentageIsTrue = false;
                        clearInterval(_this.timer)
                    }, 500)
                })
            } else {
                let formData = new FormData();
                formData.append("multipartFile", file.file);
                this.Api.uploadText(formData).then(res => {
                    console.log(res, "上传的文件")
                    this.$set(this.fileList, this.fileList.length - 1, {
                        name: res.data.fileName,
                        type: FileExt,
                        url: res.data.url,
                        size: file.file.size
                    })
                    console.log(this.fileList, "newfilelist");
                    _this.percentageNmb = 100;
                    setTimeout(function () {
                        _this.percentageIsTrue = false;
                        clearInterval(_this.timer)
                    }, 500)
                })
            }
        },
        //阵子面貌列表获取
        getDropDownlsit() {
            const _this = this
            this.Api.getDropDownlsit({
                typeCode: "POLITICAL_OUTLOOK"
            }).then(res => {
                if (res) {
                    // console.log(res, "xialai列表")
                    res.data.forEach(function (item, index) {
                        _this.columns3.push(item.itemName)
                    })

                }
                // console.log(this.columns2, "this.columns2")
            })
        },

        goBack() {
            this.$route.go(-1);
        },
        //单位
        onConfirm(value) {
            this.$store.commit('set_Company', value)
            this.ruleForm.Company = this.$store.state.Company
            this.showPicker = false;
            const _this = this;
            let item = this.columnsCopy.filter(function (item, index, arry) {
                return item.name === _this.ruleForm.Company;
            });
            this.danweiID = item[0].id;
            console.log(this.danweiID, "this.danweiID")
        },
        //问题类别
        onConfirm1(value) {
            this.ruleForm.Company1 = value;
            this.ruleForm.Company2 = "";
            this.showPicker1 = false;
            //调用获取问题细类的列表函数
            this.inputChange();
        },
        onConfirm2(value) {
            this.ruleForm.Company2 = value;
            this.showPicker2 = false;
            //问题细类
            if (this.ruleForm.Company2) {
                const _this = this;
                let item = this.questionList2.filter(function (item, index, arry) {
                    return item.itemName === _this.ruleForm.Company2;
                });
                this.savevalue2 = item[0].itemValue;
            }
        },
        onConfirm3(value) {
            this.ruleForm.Companyzhengzi = value;
            this.zengzhi = false;
        },
        onClickLeft() {
            // Toast("返回");
            this.$router.push({
                name: "info"
            });
            // this.$route.go(-1);
        },
        //表单提交时间。只有当校验通过时才会触发
        onSubmit(values) {
            this.attachList = [];
            this.fileList.forEach((item, index) => {
                this.attachList.push({
                    name: item.name,
                    url: item.url,
                    size: item.size,
                })
            })
            this.Api.ReportNoname({
                attachList: this.attachList,
                contactInfo: this.ruleForm.name3,
                content: this.ruleForm.message1,
                idCard: this.ruleForm.name2,
                issueChildType: this.savevalue2,
                issueType: this.savevalue1,
                name: this.ruleForm.name1,
                orgName: this.ruleForm.Company,
                personName: this.ruleForm.reportname,
                personOrgId: this.danweiID,
                personPost: this.ruleForm.reportname1,
                personRank: this.ruleForm.reportname2,
                politicalOutlook: this.ruleForm.Companyzhengzi,
                resideAddress: this.ruleForm.message2,
                title: this.ruleForm.message,
            }).then((res) => {

                if (res) {
                    sessionStorage.setItem("QUERY_CODE", res.data)
                    this.$router.push({
                        name: "success",
                        query: {
                            type: 1,
                        },
                    });
                }
                console.log(res, "tijiaoann ")
            });
        },

    },
};
</script>

<style lang="less" scoped>
.form-box {
    // padding: 0 0.4rem  0.61rem 0.4rem;
    padding: 0 0 0 0;

    .Company-box {
        position: relative;

        .van-icon-arrow {
            position: absolute;
            right: 0.4rem;
            top: 0.4rem;
        }
    }

    .text-title {
        min-height: 1.93rem;
    }
}

//抬头导航
.detail-title {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    display: flex;
    align-items: center;
    background-color: #ffffff;
    opacity: 1;

    //   border-bottom:0.01rem solid #EEEEEE ;
    .zuo-pic {
        width: 0.59rem;
        height: 0.59rem;
        padding: 0.05rem 0.16rem;
        margin-left: 0.25rem;
        position: absolute;
    }

    .title {
        font-size: 0.48rem;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 600;
        color: rgba(0, 0, 0, 1);
        line-height: 1.6rem;
        width: 100%;
        text-align: center;
    }
}

.height-160 {
    height: 1.23rem;
}

//单位
.van-field {
    border-bottom: 0.01rem solid #eeeeee;
}

/deep/.van-picker-column__item--selected {
    .van-ellipsis {
        color: #dd2126;
    }
}

/deep/.van-picker__confirm {
    color: #dd2126;
}

//输入框的lable
/deep/.van-field__label {
    font-size: 0.37rem;
    font-weight: 600;
    color: rgba(51, 51, 51, 1);
    line-height: 0.59rem;
}

//输入框的提示文字
// /deep/.van-field__control{
// }
//图片上传
/deep/.uploader-box {
    .van-uploader {
        width: 100%;
        background-color: white;

        .van-uploader__wrapper {

            // position: relative;
            .van-uploader__input-wrapper {
                width: 100%;
                padding: 0.44rem 0.4rem;
                display: flex;
                align-items: center;
                justify-content: space-between;
                // position: absolute;
            }
        }
    }

    .file-box {
        background-color: white;
        display: flex;
        flex-wrap: wrap;
        padding-left: 0.4rem;

        .item {
            width: 1.39rem;
            height: 1.39rem;
            display: flex;
            justify-content: center;
            align-items: center;
            border: 0.01rem solid #ddd;
            margin-right: 0.54rem;
            margin-bottom: 0.36rem;
            position: relative;
            margin-top: 0.15rem;

            img {
                width: 1.39rem;
                height: 1.39rem;
            }

            span {
                display: inline-block;
                text-align: center;
                width: 0.31rem;
                height: 0.31rem;
                border-radius: 50%;
                border: 0.01rem solid #B4B9BF;
                line-height: 0.31rem;
                position: absolute;
                right: -0.15rem;
                top: -0.15rem;
                background-color: #B4B9BF;
                color: white;
            }
        }
    }

    .upload-tip {
        font-size: 0.32rem;
        font-weight: 400;
        color: rgba(153, 153, 153, 1);
        line-height: 0.59rem;
        padding: 0 0 0.25rem 0.4rem;
        background-color: #f0f2f5;
    }
}

//举报人信息样式
.report-people-box {
    .people-title {
        font-size: 0.4rem;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 600;
        color: rgba(0, 0, 0, 1);
        line-height: 0.74rem;
        letter-spacing: 1px;
        background-color: #f0f2f5;
        padding-left: 0.4rem;
    }
}

//提交按钮的样式
.but-submit-box {
    padding: 0.48rem 0.4rem 0.68rem 0.4rem;
    background-color: #f0f2f5;

    .van-button--info {
        background: rgba(221, 33, 38, 1);
        border: 0.01rem solid #dd2126;

        .van-button__text {
            font-size: 0.43rem;
            font-weight: 400;
            color: rgba(255, 255, 255, 1);
            line-height: 0.64rem;
            letter-spacing: 0.2rem;
        }
    }
}

//导航栏的样式
/deep/.van-nav-bar--fixed {
    .van-nav-bar__left {
        padding-left: 0.4rem;

        i {
            color: #333333;
            width: 0.27rem;
            height: 0.49rem;
        }
    }

    .van-nav-bar__title {
        font-size: 0.48rem;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 600;
        color: rgba(0, 0, 0, 1);
        line-height: 0.67rem;
    }
}

//弹窗样式，姓名列表
.wrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
}

.block {
    width: 100%;
    height: 100%;
    background-color: #fff;

    .box {
        min-height: 100%;
        background-color: white;

        .van-search--show-action {
            padding: 0.15rem 0.4rem 0.15rem 0.4rem;

            .van-search__action {
                font-size: 0.37rem;
                font-weight: 400;
                color: rgba(221, 33, 38, 1);
                line-height: 0.53rem;
                letter-spacing: 0.05rem;
            }
        }
    }

    .van-list {
        .van-cell {
            padding: 0.52rem 0.4rem;
            border-bottom: 0.01rem solid #eeeeee;
        }

        .van-cell::after {
            content: "";
            border: 0;
        }
    }

    ul {
        height: 100%;

        li {
            padding: 0.52rem 0.4rem;
            border-bottom: 0.01rem solid #eeeeee;

            .name {
                font-size: 0.43rem;
                font-family: PingFangSC-Medium, PingFang SC;
                font-weight: 600;
                color: #333333;
                line-height: 0.6rem;
                margin-bottom: 0.14rem;
            }

            .lable {
                font-size: 0.4rem;
                font-family: PingFangSC-Regular, PingFang SC;
                font-weight: 400;
                color: #666666;
                line-height: 0.57rem;
            }
        }
    }
}

.pic-upload {
    display: flex;
    width: 100%;
    height: 1.36rem;
    justify-content: space-between;
    align-items: center;
    background-color: white;
    padding: 0 0.4rem;

}

.pic-upload-choice-box {
    .van-action-sheet__content {
        display: flex;
        flex-direction: column;
        align-items: center;

        .pic-upload-choice {
            font-size: 0.4rem;
            font-weight: 500;
            color: #666666;
            text-align: center;
            padding: 0.3rem 0;
        }
    }
}
</style>
