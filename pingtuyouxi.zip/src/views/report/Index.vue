<template>
    <div>
 
    </div>
</template>
<script>
import Vue from 'vue';
import { Button } from 'vant';
Vue.use(Button);
export default {
    
}
</script>
<style lang="less" scoped>
</style>