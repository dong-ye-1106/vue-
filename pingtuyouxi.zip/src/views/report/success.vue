<template>
<div class="container">
    <div class="height-160"></div>
    <van-nav-bar :fixed="true" title="举报成功" left-text left-arrow @click-left="onClickLeft" />
    <div class="success-box">
        <img src="@/assets/image/right.png" alt />
        <div class="title">举报成功</div>
    </div>
    <div class="grey-box"></div>
    <div class="code-box">
        <div class="code-title">举报进度查询码</div>
        <ul>
            <li v-for="(item,index) in list" :key="index">{{item}}</li>
        </ul>
        <div class="code-tip">查询进度需提供此码</div>
    </div>
</div>
</template>

<script>
import Vue from "vue";
import {
    NavBar
} from "vant";

Vue.use(NavBar);
export default {
    data() {
        return {
            list: [],
        };
    },
    computed: {
        dataMa() {
            return sessionStorage.getItem("QUERY_CODE")
        }
    },
    methods: {
        onClickLeft() {
            // Toast("返回");
            //   this.$router.push({ name: "info" });
            history.back();
        },
        ToString() {
            if (this.dataMa) {
                this.list = this.dataMa.split("");
            }
        },
    },
    created() {
        this.ToString();
    },
};
</script>

<style lang="less" scoped>
.container {
    background-color: #ffffff;
    height: 100%;
}

//导航栏的样式
/deep/.van-nav-bar--fixed {
    .van-nav-bar__left {
        padding-left: 0.4rem;

        i {
            color: #333333;
            width: 0.27rem;
            height: 0.49rem;
        }
    }

    .van-nav-bar__title {
        font-size: 0.48rem;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 600;
        color: rgba(0, 0, 0, 1);
        line-height: 0.67rem;
    }
}

.height-160 {
    height: 1.23rem;
}

//成功的盒子
.success-box {
    padding: 0.85rem 0 0.83rem 0;
    display: flex;
    flex-direction: column;
    align-items: center;

    img {
        width: 1.71rem;
        height: 1.71rem;
    }

    .title {
        font-size: 0.48rem;
        font-weight: 400;
        color: rgba(51, 51, 51, 1);
        line-height: 0.67rem;
        margin-top: 0.53rem;
    }
}

//中间灰底
.grey-box {
    height: 0.32rem;
    background-color: #f0f2f5;
}

//二维码查询区域
.code-box {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 1.15rem 0 0 0;

    .code-title {
        font-size: 0.43rem;
        font-weight: 600;
        color: rgba(51, 51, 51, 1);
        line-height: 0.6rem;
        margin-bottom: 0.64rem;
    }

    .code-tip {
        font-size: 0.35rem;
        font-weight: 400;
        color: rgba(153, 153, 153, 1);
        line-height: 0.49rem;
    }

    ul {
        display: flex;
        margin-bottom: 0.4rem;

        li {
            width: 1.29rem;
            height: 1.29rem;
            background: rgba(255, 255, 255, 1);
            border: 0.03rem solid rgba(221, 221, 221, 1);
            text-align: center;
            font-size: 0.91rem;
            border-right: 0;
        }
    }

    ul li:last-child {
        border-right: 0.03rem solid rgba(221, 221, 221, 1);
    }
}
</style>
