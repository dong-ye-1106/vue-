<template>
<div class="box">
    <form action="/">
        <van-search v-model="value" show-action shape="round" placeholder="请输入搜索关键词" @search="onSearch" @cancel="onCancel" @input="changevalue" />
    </form>
    <!--搜索时展示搜索意见-->
    <!--
    <van-list v-model="loading" :finished="finished" finished-text="没有更多了" @load="onLoad" v-if="isdisplay">
        <van-cell v-for="item in list" :key="item" :title="item" @click="valueChange(item)" />
    </van-list>
    -->

    <ul>
        <li>
            <div class="name">你好</div>
            <div class="lable">今天</div>
        </li>
        <li>
            <div class="name">你好</div>
            <div class="lable">今天</div>
        </li>
        <li>
            <div class="name">你好</div>
            <div class="lable">今天</div>
        </li>
    </ul>
</div>
</template>

<script>
import Vue from "vue";
import {
    Search,
    List,
    Cell
} from "vant";
Vue.use(List);
Vue.use(Search);
Vue.use(Cell);
export default {
    data() {
        return {
            value: "",
            list: [],
            loading: false,
            finished: false,
            //控制列表的显示
            isdisplay: false,
        };
    },
    methods: {
        onSearch(val) {
            const {
                watch
            } = this.$route.query;
            var cfg = {
                true: "ReportPeople",
                false: "Anonymous",
            };
            //   Toast(val);
            this.$router.push({
                name: cfg[watch],
                query: {
                    namevalue: this.value,
                },
            });
        },
        valueChange(item) {
            const {
                watch
            } = this.$route.query;
            var cfg = {
                true: "ReportPeople",
                false: "Anonymous",
            };
            this.value = item;
            this.$router.push({
                name: cfg[watch],
                query: {
                    namevalue: this.value,
                },
            });
        },
        onCancel() {
            //   Toast("取消");
            this.$router.go(-1);
        },
        //输入框的值改变时触发
        changevalue(value) {
            if (value) {
                console.log(value, "value");
                this.isdisplay = true;
                this.onLoad();
            } else {
                this.isdisplay = false;
            }
        },
        //搜索的列表的方法
        onLoad() {
            console.log(onload, "onload");
            this.list = [];
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            // setTimeout(() => {
            //     for (let i = 0; i < 4; i++) {
            //         this.list.push(
            //             "陈滨强"
            //         );
            //     }
            //     console.log(onload, "1")
            //     // 加载状态结束
            //     this.loading = false;
            //     console.log(onload, "2")
            //     // 数据全部加载完成
            //     if (this.list.length >= 5) {
            //         this.finished = true;
            //     }
            // }, 1000);

            // this.Api.getPeopleName({
            //     id: item.id
            // }).then(res => {
            //     if (res) {
            //         _this.columns2 = []
            //         res.data.forEach(function (item, index) {
            //             _this.columns2.push(item.itemName)
            //         })

            //     }
            // })
            if (this.$route.query.id) {
                this.Api.getPeopleName({
                    id: this.$route.query.id,
                }).then((res) => {
                    if (res) {
                        console.log(res, "res");
                        this.list = res.data;
                        this.loading = false;
                        this.finished = true;
                        this.list = [111, 1111];
                    }
                });
            } else {
                this.list = [];
                this.loading = false;
            }
        },
    },
    created() {
        document.title = "匿名举报";
    },
};
</script>

<style lang="less" scoped>
.box {
    min-height: 100%;
    background-color: white;

    .van-search--show-action {
        padding: 0.15rem 0.4rem 0.15rem 0.4rem;

        .van-search__action {
            font-size: 0.37rem;
            font-weight: 400;
            color: rgba(221, 33, 38, 1);
            line-height: 0.53rem;
            letter-spacing: 0.05rem;
        }
    }
}

.van-list {
    .van-cell {
        padding: 0.52rem 0.4rem;
        border-bottom: 0.01rem solid #eeeeee;
    }

    .van-cell::after {
        content: "";
        border: 0;
    }
}

ul {
    height: 100%;

    li {
        padding: 0.52rem 0.4rem;
        border-bottom: 0.01rem solid #eeeeee;

        .name {
            font-size: 0.43rem;
            font-family: PingFangSC-Medium, PingFang SC;
            font-weight: 600;
            color: #333333;
            line-height: 0.6rem;
            margin-bottom: 0.14rem;
        }

        .lable {
            font-size: 0.4rem;
            font-family: PingFangSC-Regular, PingFang SC;
            font-weight: 400;
            color: #666666;
            line-height: 0.57rem;

        }
    }
}
</style>
