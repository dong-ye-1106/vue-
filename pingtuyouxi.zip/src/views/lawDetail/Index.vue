<template>
<div class="detail-box">
    <!--
    <div class="detail-title">
        <img class="zuo-pic" src="@/assets/image/zuo.png" alt @touchstart="goBack" />
        <div class="title">
            <div v-html="detail.title"></div>
        </div>
    </div>
    <div class="height-160"></div>
    -->
    <van-sticky>
        <van-nav-bar :title="detail.title" left-arrow @click-left="onClickLeft" />
    </van-sticky>

    <div v-html="detail.content" class="text-body"></div>
</div>
</template>

<script>
import Vue from 'vue';
import {
    NavBar,
    Sticky
} from 'vant';
Vue.use(NavBar);
Vue.use(Sticky);
export default {
    data() {
        return {
            detail: {
                title: "",
                content: "",
            },
        };
    },
    created() {
        this.get();
        document.title = "法律法规";
    },
    methods: {
        onClickLeft() {
            this.$router.go(-1);
        },
        get() {
            let id = this.$route.query.id;
            console.log(id, "id");
            this.Api.regulationPageDetail({
                id: id,
            }).then((res) => {
                console.log(res, "res");
                if (res) {
                    if (res.code === "0") {
                        this.detail = res.data;
                    }
                }
            });
        },
    },
};
</script>

<style lang="less" scoped>
.detail-box {
    background-color: #ffffff;
    min-height: 100%;

    .height-160 {
        height: 1.6rem;
    }

    .detail-title {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        display: flex;
        align-items: center;
        background-color: #ffffff;
        opacity: 1;

        .zuo-pic {
            width: 0.59rem;
            height: 0.59rem;
            padding: 0.05rem 0.16rem;
            margin-left: 0.25rem;
            position: absolute;

        }

        .title {
            font-size: 0.48rem;
            font-family: PingFangSC-Medium, PingFang SC;
            font-weight: 600;
            color: rgba(0, 0, 0, 1);
            line-height: 1.6rem;
            width: 100%;
            text-align: center;
        }
    }

    .text-body {
        padding: 0 0.53rem;
        font-size: 0.35rem;
        font-weight: 500;
        color: rgba(51, 51, 51, 1);
        line-height: 0.56rem;
        min-height: 100%;
    }
}

/deep/.van-ellipsis {
    white-space: normal;
    word-break: break-all;
    word-wrap: break-word;
    text-align: center;
    font-size: 0.48rem;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 600;
    color: #000000;
    line-height: 0.67rem;

}

/deep/.van-nav-bar {
    height: auto;
    padding: 0.26rem 0 0.69rem 0;
}

/deep/.van-icon {
    color: #333333;
    width: 0.59rem;
    height: 0.59rem;

}

/deep/.van-hairline--bottom::after {
    border: 0;
}
</style>
