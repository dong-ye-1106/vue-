<template>
<div class="bg-white">
    <div class="height-160"></div>
    <van-nav-bar :fixed="true" title="举报查询" left-text left-arrow @click-left="onClickLeft" />
    <van-form @submit="onSubmit">
        <van-field v-model="value" placeholder="请输入查询码" :rules="[{ pattern, message: '请输入六位查询码' }]" />
        <van-button type="query">查询</van-button>
    </van-form>
</div>
</template>

<script>
import Vue from "vue";
import {
    NavBar,
    Field,
    Button,
    Form,
    Notify
} from "vant";
Vue.use(Field);
Vue.use(NavBar);
Vue.use(Button);
Vue.use(Form);
Vue.use(Notify);
export default {
    data() {
        return {
            value: "",
            pattern: /^.{6,}$/,
        };
    },
    created() {
        document.title = "举报查询";
    },
    methods: {
        onClickLeft() {
            // Toast("返回");
            //   this.$router.push({ name: "info" });
            history.back();
        },
        //查询
        onSubmit(values) {
            this.value = this.value.replace(/[, ]/g, '')
            this.Api.ReportNowLook({
                code: this.value,
            }).then((res) => {
                console.log(res, "举报查询");
                if (res.data !== null) {
                    this.$router.push({
                        name: "result",
                        query: {
                            code: this.value
                        }
                    });
                } else {
                    Notify({
                        type: 'warning',
                        message: '查询码有误'
                    });
                }
            });

        },
    },
};
</script>

<style lang="less" scoped>
//导航栏的样式
/deep/.van-nav-bar--fixed {
    .van-nav-bar__left {
        padding-left: 0.4rem;

        i {
            color: #333333;
            width: 0.27rem;
            height: 0.49rem;
        }
    }

    .van-nav-bar__title {
        font-size: 0.48rem;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 600;
        color: rgba(0, 0, 0, 1);
        line-height: 0.67rem;
    }
}

.height-160 {
    height: 1.23rem;
}

.bg-white {
    padding: 0 0.4rem 0 0.4rem;
}

.van-field {
    padding: 0.74rem 0 0.39rem 0;
    border-bottom: 0.01rem solid #eeeeee;
    margin-bottom: 0.47rem;
}

.van-button--query {
    width: 9.2rem;
    height: 1.25rem;
    background: rgba(221, 33, 38, 1);
    border-radius: 0.05rem;
    border: 0;

    .van-button__content {
        font-size: 0.48rem;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: rgba(255, 255, 255, 1);
        line-height: 0.67rem;
        letter-spacing: 0.2rem;
    }
}
</style>
