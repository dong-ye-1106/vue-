<template>
<div class="bg-white">
    <div class="height-160"></div>
    <van-nav-bar :fixed="true" title="举报详情" left-text left-arrow @click-left="onClickLeft" />
    <div class="detail-box">
        <div class="title" v-if="detail.status==0">待处理</div>
        <div class="title" v-if="detail.status==1">已受理</div>
        <div class="title" v-if="detail.status==2">已驳回</div>
        <div class="title" v-if="detail.status==3">立案调查</div>
        <div class="detail-body">
            <div class="detail-top">
                <div class="item">
                    <h1 class="width-auto">
                        <span class="span-1">标</span>
                        <span class="span-2">题</span>
                    </h1>
                    <span>{{detail.title}}</span>
                </div>
                <div class="item">
                    <h1>举报方式</h1>
                    <span v-if="detail.type==1">匿名举报</span>
                    <span v-if="detail.type==2">实名举报</span>
                </div>
                <div class="item">
                    <h1>举报时间</h1>
                    <span>{{detail.createdTime}}</span>
                </div>
                <div class="item">
                    <h1>处理状态</h1>
                    <span class="color-blue" v-if="detail.status==='0'">待处理</span>
                    <span class="color-origin" v-if="detail.status==='1'">已受理</span>
                    <span class="color-green" v-if="detail.status==='2'">已驳回</span>
                    <span class="color-red" v-if="detail.status==='3'">立案调查</span>
                    <span class="color-red" v-else></span>
                </div>
            </div>
            <div class="detail-bottom">
                <div class="bottom-title">状态详情</div>
                <div class="bottom-box2" v-if="detail.status==='2'">
                    <div class="item persion-css" v-if="!detail.approvedTime">
                        <h1 class="">受理时间</h1>
                        <span>111111{{detail.approvedTime}}</span>
                    </div>
                    <div class="item persion-css">
                        <h1 class="tip">驳回理由</h1>
                        <span>{{detail.opinion}}</span>
                    </div>
                </div>
                <div class="bottom-box" v-else>
                    <div class="item" v-if="detail.approvedTime">
                        <h1>受理时间</h1>
                        <span>{{detail.approvedTime}}</span>
                    </div>
                    <div class="item" v-if="detail.surveyedTime">
                        <h1>开启立案调查时间</h1>
                        <span>{{detail.surveyedTime}}</span>
                    </div>
                    <div class="item">
                        <div class="item-tip">{{detail.opinion}}</div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
</template>

<script>
import Vue from "vue";
import {
    NavBar,
    Notify
} from "vant";

Vue.use(NavBar);
Vue.use(Notify);
export default {
    data() {
        return {
            title: "标题",
            detail: {
                title: "",
                type: "",
                createdTime: "",
                status: "4",
                opinion: ""
            },
        };
    },
    created() {
        this.ReportNowLook()
    },
    methods: {
        ReportNowLook() {
            this.Api.ReportNowLook({
                code: this.$route.query.code,
            }).then((res) => {
                if (res.code === "0") {
                    // console.log(res, "举报查询");
                    this.detail = res.data
                } else {
                    Notify({
                        type: 'warning',
                        message: '查询码有误'
                    });
                }
            });
        },
        onClickLeft() {
            // Toast("返回");
            //   this.$router.push({ name: "info" });
            history.back();
        },
    },
};
</script>

<style lang="less" scoped>
//导航栏的样式
/deep/.van-nav-bar--fixed {
    .van-nav-bar__left {
        padding-left: 0.4rem;

        i {
            color: #333333;
            width: 0.27rem;
            height: 0.49rem;
        }
    }

    .van-nav-bar__title {
        font-size: 0.48rem;
        font-weight: 600;
        color: rgba(0, 0, 0, 1);
        line-height: 0.67rem;
    }
}

.height-160 {
    height: 1.23rem;
}

.bg-white {
    .detail-box {
        padding: 0.4rem 0.4rem 0 0.4rem;

        .title {
            font-size: 0.56rem;
            font-family: PingFangSC-Medium, PingFang SC;
            font-weight: 600;
            color: rgba(0, 0, 0, 1);
            line-height: 0.79rem;
            letter-spacing: 2px;
            margin-bottom: 0.4rem;
        }

        .detail-body {
            .detail-top {
                .item {
                    display: flex;
                    align-items: center;

                    h1 {
                        display: inline-block;
                        font-size: 0.4rem;
                        font-weight: 400;
                        color: rgba(153, 153, 153, 1);
                        line-height: 0.96rem;
                        letter-spacing: 2px;
                        margin-right: 0.69rem;

                        .span-1 {
                            font-size: 0.4rem;
                            font-weight: 400;
                            color: rgba(153, 153, 153, 1);
                            line-height: 0.96rem;
                            letter-spacing: 2px;
                            margin-right: 0.9rem;
                        }

                        .span-2 {
                            font-size: 0.4rem;
                            font-weight: 400;
                            color: rgba(153, 153, 153, 1);
                            line-height: 0.96rem;
                            letter-spacing: 2px;
                        }
                    }

                    .width-auto {
                        flex: 0 0 1.84rem;
                    }

                    span {
                        font-size: 0.4rem;
                        font-weight: 400;
                        color: rgba(0, 0, 0, 1);
                        line-height: 0.96rem;
                        letter-spacing: 1px;
                        white-space: normal;
                        word-break: break-all;
                        word-wrap: break-word;
                    }
                }
            }

            .detail-bottom {
                .bottom-title {
                    font-size: 0.4rem;
                    font-family: PingFangSC-Medium, PingFang SC;
                    font-weight: 600;
                    color: rgba(0, 0, 0, 1);
                    line-height: 0.56rem;
                    letter-spacing: 1px;
                    padding: 0.69rem 0 0.26rem 0;
                }

                .bottom-box {
                    .item {
                        display: flex;
                        align-items: center;

                        >h1 {
                            font-size: 0.4rem;
                            font-weight: 400;
                            color: rgba(153, 153, 153, 1);
                            line-height: 0.56rem;
                            letter-spacing: 1px;
                            padding: 0.15rem 0;
                            width: 3.43rem;
                            margin-right: 0.67rem;
                        }

                        span {
                            font-size: 0.4rem;
                            font-weight: 400;
                            color: rgba(0, 0, 0, 1);
                            line-height: 0.56rem;
                            letter-spacing: 1px;
                        }
                    }

                    .item-tip {
                        font-size: 0.4rem;
                        font-family: PingFangSC-Regular, PingFang SC;
                        font-weight: 400;
                        color: rgba(51, 51, 51, 1);
                        line-height: 0.56rem;
                        letter-spacing: 1px;
                        padding-top: 0.24rem;
                    }

                }

                .bottom-box2 {
                    .item {
                        display: flex;
                        align-items: center;

                        h1 {
                            font-size: 0.4rem;
                            font-weight: 400;
                            color: rgba(153, 153, 153, 1);
                            line-height: 0.56rem;
                            letter-spacing: 1px;
                            padding: 0.15rem 0;
                            margin-right: 0.67rem;
                        }

                        .tip {
                            font-size: 0.4rem;
                            font-weight: 400;
                            color: rgba(153, 153, 153, 1);
                            line-height: 0.56rem;
                            letter-spacing: 1px;
                            padding: 0.15rem 0;
                            margin-right: 0.67rem;
                            width: 2rem;
                        }

                        span {
                            font-size: 0.4rem;
                            font-weight: 400;
                            color: rgba(0, 0, 0, 1);
                            line-height: 0.56rem;
                            letter-spacing: 1px;
                        }
                    }
                }
            }
        }
    }
}

.color-red {
    color: #dd2126 !important;
}

.color-origin {
    color: #FA6400 !important;
}

.color-green {
    color: #007D1E !important;
}

.color-blue {
    color: #147BFD !important;
}
</style>
