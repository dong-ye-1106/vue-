

<template>
  <div>
    <div ref="game" style="position: relative;"></div>
  </div>
</template>

<script>
export default {
  name: "pingtu",
  props: {
    config: {
      type: Object,
      default: () => {
        return {
          width: 500,
          height: 500,
          img: "https://scpic.chinaz.net/files/pic/pic9/202107/bpic23752.jpg",
          // 三行三列
          row: 3,
          col: 3,
          border:"2px solid #000000"
        };
      },
    },
  },
  data() {
    return {
      computed: {
        num: null, // 小方块的数量
        w: null, // 每个小方块的宽度
        h: null, // 每个小方块的高度
      },
      // 装小方块对象的数组，每个元素是一个对象，每个对象中记录了方块的
      // 最初的坐标、当前的坐标、dom元素、一些方法
      squares: [],
    };
  },
  mounted() {
    this.computed = {
      num: this.config.col * this.config.row, // 小方块的数量
      w: this.config.width / this.config.col, // 每个小方块的宽度
      h: this.config.height / this.config.row, // 每个小方块的高度
    };
    this.setBlocks();
    this.generateGame();
  },
  methods: {
    generateGame() {
        // 设置区域大小和范围
      this.$refs.game.style.width = this.config.width+4 + "px";
      this.$refs.game.style.height = this.config.height+4 + "px";
      this.$refs.game.style.border = this.config.border;
        //渲染生成的每个小方块   
      for (const item of this.squares) {
        if (!item.isEmpty) {
          this.$refs.game.appendChild(item.dom);
        }
      }
    },
    setBlocks() {
      let that = this;
      var points = this.getPointsArray(); // 返回的数组用来设置每个方块最初的位置
      var shuffledPoints = [...points]; // 复制points数组，用来存放变化后每个小方块的位置
      this.shuffle(shuffledPoints); // 打乱每个小方块的位置
      for (var i = 0; i < points.length; i++) {
        const point = points[i];
        //  创建方块对象
        var square = {
          left: point.left,
          top: point.top,
          curLeft: shuffledPoints[i].left,
          curTop: shuffledPoints[i].top,
          dom: document.createElement("div"),
          update() {
            this.dom.style.transition = "all, .5s"; // 设置延迟
            this.dom.style.left = this.curLeft + "px"; // 设置当前的位置
            this.dom.style.top = this.curTop + "px"; // 当前高度
          },
          isEmpty: i === points.length - 1,
          isCorrect() {
            return this.curTop === this.top && this.curLeft === this.left;
          },
        };
        square.dom.style.width = this.computed.w + "px"; // 设置宽高
        square.dom.style.height = this.computed.h + "px";
        square.dom.style.position = "absolute";
        square.dom.style.border = "1px solid #fff";
        square.dom.style.boxSizing = "border-box";
        square.dom.style.background = `url("${this.config.img}")`; // 模板字符串
        square.dom.style.cursor = "pointer";
        square.dom.style.backgroundPosition =
        -square.left + "px " + -square.top + "px";
        square.dom.block = square;
        //当小方块被点击时，如果与空白块相邻就交换位置
        square.dom.onclick = function () {
          that.switchSquare(this.block);
        };
        square.update(); // 初始化每个方块的位置
        this.squares.push(square); // 将每个小方块对象存入数组中
      }
    },
    switchSquare(block) {
      // 找到空白块
      // ES6的数组扩展语法：数组实例find方法：找到第一个符合条件的数组成员
      var emptySquare = this.squares.find(function (index) {
        return index.isEmpty;
      });
      // 判断是否相邻
      if (
        Math.abs(block.curLeft - emptySquare.curLeft) +
          Math.abs(block.curTop - emptySquare.curTop) !==
        this.computed.w
      ) {
        return;
      }
      // 交换
      var bLeft = block.curLeft; // 先保存当前被点击方块的位置
      var bTop = block.curTop;
      block.curLeft = emptySquare.curLeft; // 再交换
      block.curTop = emptySquare.curTop;
      emptySquare.curLeft = bLeft;
      emptySquare.curTop = bTop;
      // 更新点击方块与空白格的位置
      block.update();
      emptySquare.update();
      // 判断游戏结束
      if (this.isWin()) {
        setTimeout(() => {
          alert("游戏结束");
        }, 500);
      }
    },
    isWin() {
      for (const s of this.squares) {
        if (!s.isCorrect()) {
          return false;
        }
      }
      return true;
    },
    shuffle(arr) {
      for (var i = 0; i < arr.length - 1; i++) {
        var randomIndex = Math.floor(Math.random() * (arr.length - 1));
        var temp = arr[i];
        arr[i] = arr[randomIndex];
        arr[randomIndex] = temp;
      }
    },
    // 设置每个方块最初的位置
    getPointsArray() {
        // 设置一个空数组
      var arr = [];
        // 生成对应数量的dom点坐标  
      for (var i = 0; i < this.computed.num; i++) {
        arr.push({
          left: (i % this.config.col) * this.computed.w,
          top: parseInt(i / this.config.col) * this.computed.h,
        });
      }
      return arr;
    },
  },
};
</script>

<style lang="less" scoped>
</style>