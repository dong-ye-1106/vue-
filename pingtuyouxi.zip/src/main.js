import Vue from 'vue'
import App from './App.vue'
import './assets/css/common.css'
import axios from 'axios'
import { store } from "@/store/index.js"
import Api from '@/api'
import router from "@/router/index.js"
//  require styles 引入样式
Vue.config.productionTip = false
Vue.prototype.$http = axios
Vue.prototype.Api = Api
Vue.config.productionTip = false
Vue.prototype.$http = axios
// 引入amfe-flexible
import 'amfe-flexible/index'
new Vue({
  router, store,
  render: h => h(App),
}).$mount('#app')
