
const autoprefixer = require('autoprefixer')
const pxtorem = require('postcss-pxtorem')
module.exports = {
    // devServer: {
    //     port: 8801,
    //     open: true,
    //     proxy: {
    //         "/api": {
    //             target: "http://192.168.2.34:8080/",
    //             changeOrign: true,
    //             pathRewrite: {
    //                 "^/api": ""
    //             }
    //         }
    //     }
    // },
    lintOnSave: false,//彻底关闭eslint，
    css: {
        loaderOptions: {
            postcss: {
                plugins: [
                    autoprefixer(),
                    pxtorem({
                        rootValue: 37.5,  // 根字体大小，如果设计图是750的话 记得除2
                        unitPrecision: 5,
                        propList: ['*'], // 作用在哪些属性上 我这里用的是通配符
                        selectorBlackList: ['vant-'], // 将哪些html元素排除在外，我这里添加了一个vant的
                        replace: true,
                        mediaQuery: false,
                        minPixelValue: 0,
                        exclude: /node_modules/i
                    })
                ]
            }
        }
    },

}